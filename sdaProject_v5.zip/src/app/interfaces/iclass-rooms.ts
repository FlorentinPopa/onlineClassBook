export interface IclassRooms {
  numeClasa: string;
  ProfesorID: number;
  ElevID: number;
}
