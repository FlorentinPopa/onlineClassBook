export interface IGrade {
  nota: number;
  idElev: number;
  idProfesor: number;
  numeMaterie: string;
}
