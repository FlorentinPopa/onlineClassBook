export interface IClassName {
  nume: string;
}
