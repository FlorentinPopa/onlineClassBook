export interface ITeacher {
  id?: number;
  name: string;
  email: string;
  password: string;
  materie: string;
}
