export interface IstudentDetails {
  nota: number;
  numeMaterie: string;
  nume: string;
  name: string;
}
