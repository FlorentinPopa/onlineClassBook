export class Student {
  id: number;
  nume: string;
  email: string;
  password: string;
}
