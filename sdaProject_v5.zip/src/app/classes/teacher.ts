export class Teacher {
  id: number;
  name: string;
  email: string;
  password: string;
  materie: string;
}
