export interface IStudent {
  id?: number;
  nume: string;
  email: string;
  password: string;
}
